class AttendanceAgent:
    def __init__(self, threshold=0.72):
        self.threshold = threshold

    def decide(self, face_match, distance, blink_ok, head_ok):
        if not face_match:
            return "REJECT", "Unknown face"

        if distance > self.threshold:
            return "RETRY", "Low confidence"

        if not blink_ok or not head_ok:
            return "RETRY", "Liveness failed"

        return "MARK", "Attendance marked"
