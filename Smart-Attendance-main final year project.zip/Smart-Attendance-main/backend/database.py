import sqlite3
import os
import hashlib
from contextlib import contextmanager
from datetime import datetime

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
DB = os.path.join(BASE_DIR, "data", "attendance.db")


@contextmanager
def _get_conn():
    os.makedirs(os.path.dirname(DB), exist_ok=True)
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    try:
        yield con
    finally:
        con.close()


def _hash(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def reset_password(student_id: str, new_password: str) -> bool:
    """Reset a student's password. Returns True if student found and updated."""
    with _get_conn() as con:
        cur = con.execute(
            "UPDATE students SET password=? WHERE student_id=?",
            (_hash(new_password), student_id)
        )
        con.commit()
        return cur.rowcount > 0


# ============================================================
# INIT
# ============================================================
_col_cache: dict = {}

def _existing_columns_cached(table: str = "attendance") -> set:
    if table not in _col_cache:
        with _get_conn() as con:
            _col_cache[table] = _existing_columns(con, table)
    return _col_cache[table]


def _existing_columns(con, table: str) -> set:
    rows = con.execute(f"PRAGMA table_info({table})").fetchall()
    return {r["name"] for r in rows}


def init_db():
    with _get_conn() as con:
        # Students (registered by admin)
        con.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                name        TEXT    NOT NULL,
                student_id  TEXT    UNIQUE NOT NULL,
                class_name  TEXT    NOT NULL,
                password    TEXT    NOT NULL,
                created_at  TEXT    NOT NULL
            )
        """)

        # Timetable (configurable by admin)
        con.execute("""
            CREATE TABLE IF NOT EXISTS timetable (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                class_name  TEXT    NOT NULL,
                subject     TEXT    NOT NULL,
                day         TEXT    NOT NULL,
                period      INTEGER NOT NULL,
                start_time  TEXT    NOT NULL,
                end_time    TEXT    NOT NULL
            )
        """)

        # Attendance — UNIQUE per student per hour (auto-resets each hour)
        con.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                student_id  TEXT    NOT NULL,
                name        TEXT    NOT NULL,
                class_name  TEXT,
                date        TEXT    NOT NULL,
                hour        INTEGER NOT NULL,
                time        TEXT    NOT NULL,
                period      INTEGER,
                subject     TEXT,
                status      TEXT    NOT NULL,
                UNIQUE(student_id, date, hour)
            )
        """)

        # ── Migration: add columns missing from older schema versions ──
        att_cols = _existing_columns(con, "attendance")
        migrations = [
            ("student_id",   "ALTER TABLE attendance ADD COLUMN student_id TEXT NOT NULL DEFAULT ''"),
            ("class_name",   "ALTER TABLE attendance ADD COLUMN class_name TEXT"),
            ("hour",         "ALTER TABLE attendance ADD COLUMN hour INTEGER NOT NULL DEFAULT 0"),
            ("period",       "ALTER TABLE attendance ADD COLUMN period INTEGER"),
            ("subject",      "ALTER TABLE attendance ADD COLUMN subject TEXT"),
            ("period_start", "ALTER TABLE attendance ADD COLUMN period_start TEXT"),
            # Old schema had action NOT NULL; give it a permanent default so inserts without it still work
            ("action",       None),  # already exists in old schema — no ADD needed
        ]
        for col, sql in migrations:
            if col not in att_cols and sql:
                con.execute(sql)

        # Make 'action' column optional (old schema has it as NOT NULL with no default).
        # Safest cross-SQLite approach: ensure every old row has a value, then rely on
        # new inserts always supplying it.
        if "action" in _existing_columns(con, "attendance"):
            con.execute("UPDATE attendance SET action='MARK' WHERE action IS NULL OR action=''")


        # Backfill hour=0 for any pre-migration rows that have hour NULL/missing
        con.execute("UPDATE attendance SET hour = 0 WHERE hour IS NULL")
        # Backfill student_id from name for pre-migration rows
        con.execute("UPDATE attendance SET student_id = name WHERE student_id = ''")

        con.commit()


# ============================================================
# STUDENTS
# ============================================================
def add_student(name: str, student_id: str, class_name: str, password: str) -> bool:
    with _get_conn() as con:
        try:
            con.execute(
                "INSERT INTO students (name, student_id, class_name, password, created_at) VALUES (?,?,?,?,?)",
                (name, student_id, class_name, _hash(password), datetime.now().isoformat())
            )
            con.commit()
            return True
        except sqlite3.IntegrityError:
            return False


def get_student_by_sid(student_id: str) -> dict | None:
    with _get_conn() as con:
        row = con.execute(
            "SELECT * FROM students WHERE student_id = ?", (student_id,)
        ).fetchone()
    return dict(row) if row else None


def get_all_students() -> list:
    with _get_conn() as con:
        rows = con.execute(
            "SELECT id, name, student_id, class_name, created_at FROM students ORDER BY class_name, name"
        ).fetchall()
    return [dict(r) for r in rows]


def get_classes() -> list:
    """Return distinct class names."""
    with _get_conn() as con:
        rows = con.execute(
            "SELECT DISTINCT class_name FROM students ORDER BY class_name"
        ).fetchall()
    return [r["class_name"] for r in rows]


def verify_student_login(student_id: str, password: str) -> dict | None:
    student = get_student_by_sid(student_id)
    if student and student["password"] == _hash(password):
        return student
    return None


def delete_student(student_id: str):
    with _get_conn() as con:
        con.execute("DELETE FROM students WHERE student_id = ?", (student_id,))
        con.commit()


# ============================================================
# TIMETABLE
# ============================================================
def add_timetable_entry(class_name: str, subject: str, day: str,
                        period: int, start_time: str, end_time: str):
    with _get_conn() as con:
        con.execute(
            "INSERT INTO timetable (class_name, subject, day, period, start_time, end_time) VALUES (?,?,?,?,?,?)",
            (class_name, subject, day, period, start_time, end_time)
        )
        con.commit()


def get_timetable() -> list:
    with _get_conn() as con:
        rows = con.execute(
            "SELECT * FROM timetable ORDER BY day, period, start_time"
        ).fetchall()
    return [dict(r) for r in rows]


def get_timetable_for_class(class_name: str) -> list:
    with _get_conn() as con:
        rows = con.execute(
            "SELECT * FROM timetable WHERE class_name = ? ORDER BY day, period",
            (class_name,)
        ).fetchall()
    return [dict(r) for r in rows]


def delete_timetable_entry(entry_id: int):
    with _get_conn() as con:
        con.execute("DELETE FROM timetable WHERE id = ?", (entry_id,))
        con.commit()


def get_current_period(class_name: str) -> dict | None:
    """Return the active timetable entry for this class right now, or None."""
    now         = datetime.now()
    current_day = now.strftime("%a")          # Mon, Tue, …
    current_hm  = now.strftime("%H:%M")
    with _get_conn() as con:
        row = con.execute("""
            SELECT * FROM timetable
            WHERE class_name = ?
              AND (day = ? OR day = 'All')
              AND start_time <= ?
              AND end_time   >  ?
            LIMIT 1
        """, (class_name, current_day, current_hm, current_hm)).fetchone()
    return dict(row) if row else None


# ============================================================
# ATTENDANCE  — resets each new hour automatically
# ============================================================
def is_already_marked(student_id: str, period_start: str = None) -> bool:
    """
    Check whether the student already has an attendance record for the
    current active period.

    If period_start is provided (e.g. "13:40") the check is period-scoped —
    the window closes at the period's end_time, not at the clock-hour boundary.
    Falls back to clock-hour check when period_start is None.
    """
    if not student_id:
        return False
    today = datetime.now().date().isoformat()
    with _get_conn() as con:
        if period_start:
            row = con.execute(
                "SELECT 1 FROM attendance WHERE student_id=? AND date=? AND period_start=? LIMIT 1",
                (student_id, today, period_start)
            ).fetchone()
        else:
            hour = datetime.now().hour
            row = con.execute(
                "SELECT 1 FROM attendance WHERE student_id=? AND date=? AND hour=? LIMIT 1",
                (student_id, today, hour)
            ).fetchone()
    return row is not None


def mark_attendance(student_id: str, name: str, class_name: str = "",
                    period: int = None, subject: str = "", status: str = "Verified",
                    period_start: str = None):
    now  = datetime.now()
    cols = _existing_columns_cached()
    # Include 'action' only if the column exists (old schema compatibility)
    if "action" in cols:
        sql  = """INSERT INTO attendance
                    (student_id, name, class_name, date, hour, time, period, subject, status, period_start, action)
                  VALUES (?,?,?,?,?,?,?,?,?,?,?)"""
        vals = (student_id, name, class_name,
                now.date().isoformat(), now.hour, now.strftime("%H:%M:%S"),
                period, subject, status, period_start, "MARK")
    else:
        sql  = """INSERT INTO attendance
                    (student_id, name, class_name, date, hour, time, period, subject, status, period_start)
                  VALUES (?,?,?,?,?,?,?,?,?,?)"""
        vals = (student_id, name, class_name,
                now.date().isoformat(), now.hour, now.strftime("%H:%M:%S"),
                period, subject, status, period_start)
    with _get_conn() as con:
        try:
            con.execute(sql, vals)
            con.commit()
        except sqlite3.IntegrityError:
            pass  # Already marked this hour


def get_all_attendance() -> list:
    with _get_conn() as con:
        rows = con.execute("""
            SELECT name, class_name, date, time, period, subject, status
            FROM attendance
            ORDER BY date DESC, time DESC
        """).fetchall()
    return [dict(r) for r in rows]


def get_attendance_by_student(student_id: str) -> list:
    with _get_conn() as con:
        rows = con.execute("""
            SELECT date, time, period, subject, class_name, status
            FROM attendance
            WHERE student_id = ?
            ORDER BY date DESC, time DESC
        """, (student_id,)).fetchall()
    return [dict(r) for r in rows]


def get_attendance_today() -> list:
    today = datetime.now().date().isoformat()
    with _get_conn() as con:
        rows = con.execute("""
            SELECT student_id, name, class_name, time, period, subject
            FROM attendance
            WHERE date = ?
            ORDER BY time DESC
        """, (today,)).fetchall()
    return [dict(r) for r in rows]


def get_today_stats() -> dict:
    today = datetime.now().date().isoformat()
    with _get_conn() as con:
        total_students  = con.execute("SELECT COUNT(*) FROM students").fetchone()[0]
        marked_today    = con.execute(
            "SELECT COUNT(DISTINCT student_id) FROM attendance WHERE date=?", (today,)
        ).fetchone()[0]
    return {"total_students": total_students, "marked_today": marked_today}
