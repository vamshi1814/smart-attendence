import os
import sys
import cv2
import base64
import time
import logging
import numpy as np
import mediapipe as mp
from deepface import DeepFace
from numpy.linalg import norm

# ---------- PATH FIX ----------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, BASE_DIR)

from database import mark_attendance, is_already_marked
from object_guard import detect_device

logger = logging.getLogger(__name__)

# ---------- CONFIG ----------
KNOWN_FACES     = os.path.join(BASE_DIR, "data", "known_faces")
THRESHOLD       = 0.72
ACK_TIME        = 4   # seconds to freeze display after marking

# ---------- LIVENESS THRESHOLDS ----------
BLINK_CLOSE_EAR = 0.20   # genuine blink closes below this
BLINK_OPEN_EAR  = 0.25   # hysteresis — reopens above this
HEAD_MOVE_RATIO = 0.07   # 7% of frame width per direction (~34 px at 480 px wide)

# ---------- MEDIAPIPE ----------
mp_face_mesh = mp.solutions.face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

LEFT_EYE  = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]
NOSE_TIP  = 1

# ---------- LIVENESS STATE (global, single-user) ----------
_blink_done     = False
_eye_closed     = False
_head_left      = False
_head_right     = False
_initial_nose_x = None
_last_message      = ""
_last_message_time = 0.0

# ---------- EMBEDDING CACHE ----------
_emb_cache: dict = {}
_emb_mtime: dict = {}


def _load_embeddings() -> dict:
    if not os.path.exists(KNOWN_FACES):
        return {}
    current = {f for f in os.listdir(KNOWN_FACES) if f.endswith(".npy")}
    for fname in current:
        fpath = os.path.join(KNOWN_FACES, fname)
        mtime = os.path.getmtime(fpath)
        if fname not in _emb_cache or _emb_mtime.get(fname) != mtime:
            _emb_cache[fname] = np.load(fpath)
            _emb_mtime[fname] = mtime
    for fname in list(_emb_cache):
        if fname not in current:
            del _emb_cache[fname]
            del _emb_mtime[fname]
    return _emb_cache


def _load_student_embedding(name: str) -> np.ndarray | None:
    """Load a single student's embedding by name."""
    fpath = os.path.join(KNOWN_FACES, f"{name}.npy")
    if not os.path.exists(fpath):
        return None
    return np.load(fpath)


# ---------- UTILITIES ----------
def decode_image(b64: str):
    try:
        if not b64 or "," not in b64:
            return None
        data = base64.b64decode(b64.split(",")[1])
        return cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR) if data else None
    except Exception as e:
        logger.error("decode_image: %s", e)
        return None


def _eye_ratio(eye, lm, w, h) -> float:
    v  = abs(lm[eye[1]].y - lm[eye[5]].y) * h
    h_ = abs(lm[eye[0]].x - lm[eye[3]].x) * w
    return v / max(h_, 1e-6)


def _cosine(a, b) -> float:
    return 1.0 - np.dot(a, b) / (norm(a) * norm(b))


def _frozen() -> bool:
    return time.time() - _last_message_time < ACK_TIME


def _freeze(msg: str) -> dict:
    global _last_message, _last_message_time
    _last_message      = msg
    _last_message_time = time.time()
    return {"message": msg}


def reset_session():
    """Reset liveness state. Call when a student opens the attendance page."""
    global _blink_done, _eye_closed, _head_left, _head_right, _initial_nose_x
    global _last_message, _last_message_time
    _blink_done     = False
    _eye_closed     = False
    _head_left      = False
    _head_right     = False
    _initial_nose_x = None
    _last_message      = ""
    _last_message_time = 0.0


# ============================================================
# REGISTER FACE
# ============================================================
def register_face(name: str, image_b64: str) -> dict:
    frame = decode_image(image_b64)
    if frame is None:
        return {"message": "Camera error"}

    face = cv2.resize(frame, (224, 224))
    face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)

    embedding = DeepFace.represent(
        img_path=face, model_name="VGG-Face",
        detector_backend="skip", enforce_detection=False
    )[0]["embedding"]

    os.makedirs(KNOWN_FACES, exist_ok=True)
    np.save(os.path.join(KNOWN_FACES, f"{name}.npy"), embedding)
    logger.info("Registered face: %s", name)
    return {"message": "Face registered successfully"}


# ============================================================
# TAKE ATTENDANCE
# ============================================================
def take_attendance(image_b64: str,
                    student_id: str   = None,
                    student_name: str = None,
                    class_name: str   = "",
                    period_info: dict = None) -> dict:
    global _blink_done, _eye_closed, _head_left, _head_right, _initial_nose_x

    if _frozen():
        return {"message": _last_message}

    frame = decode_image(image_b64)
    if frame is None:
        reset_session()
        return {"message": "Camera error"}

    # ---- SERVER-SIDE SCREEN CHECK (blocks phone spoofing) ----
    screen_found, _ = detect_device(frame)
    if screen_found:
        reset_session()
        logger.warning("Screen detected — blocked for %s", student_id)
        return _freeze("PHONE / SCREEN DETECTED - BLOCKED")

    h, w, _ = frame.shape
    res = mp_face_mesh.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))

    if not res.multi_face_landmarks:
        return {"message": "No face detected"}

    lm = res.multi_face_landmarks[0].landmark

    # ---- BLINK (two-threshold hysteresis) ----
    ear = (_eye_ratio(LEFT_EYE, lm, w, h) + _eye_ratio(RIGHT_EYE, lm, w, h)) / 2
    if ear < BLINK_CLOSE_EAR:
        _eye_closed = True
    elif _eye_closed and ear > BLINK_OPEN_EAR:
        _blink_done = True
        _eye_closed = False

    if not _blink_done:
        return {"message": "Blink your eyes"}

    # ---- HEAD MOVEMENT (left then right) ----
    nose_x = lm[NOSE_TIP].x * w
    if _initial_nose_x is None:
        _initial_nose_x = nose_x
    diff     = nose_x - _initial_nose_x
    min_move = w * HEAD_MOVE_RATIO

    if diff < -min_move:
        _head_left  = True
    if diff > min_move:
        _head_right = True

    if not _head_left:
        return {"message": "Turn head LEFT"}
    if not _head_right:
        return {"message": "Now turn head RIGHT"}

    # ---- FACE RECOGNITION ----
    face = cv2.cvtColor(cv2.resize(frame, (224, 224)), cv2.COLOR_BGR2RGB)
    try:
        live_emb = DeepFace.represent(
            img_path=face, model_name="VGG-Face",
            detector_backend="skip", enforce_detection=False
        )[0]["embedding"]
    except Exception as e:
        logger.error("DeepFace failed: %s", e)
        return {"message": "Recognition failed"}

    # ---- MATCH against logged-in student only (if provided) ----
    if student_id and student_name:
        emb = _load_student_embedding(student_name)
        if emb is None:
            return {"message": "Face not registered — contact admin"}
        dist = _cosine(live_emb, emb)
        if dist > THRESHOLD:
            reset_session()
            return {"message": "Face does not match your profile"}
        best_name = student_name
    else:
        # Fallback: full recognition (anonymous mode)
        embeddings = _load_embeddings()
        if not embeddings:
            return {"message": "No registered faces found"}
        best_name, min_d = None, 1.0
        for fname, emb in embeddings.items():
            d = _cosine(live_emb, emb)
            if d < min_d:
                min_d, best_name = d, fname.replace(".npy", "")
        if best_name is None or min_d > THRESHOLD:
            reset_session()
            return {"message": "Unknown face"}
        student_id = best_name

    # ---- PERIOD-BASED DUPLICATE CHECK ----
    period_start = period_info.get("start_time") if period_info else None
    if is_already_marked(student_id, period_start):
        reset_session()
        period_label = f"Period {period_info['period']}" if period_info else "this period"
        return _freeze(f"Already marked for {period_label}")

    # ---- MARK ----
    period  = period_info.get("period")  if period_info else None
    subject = period_info.get("subject") if period_info else ""
    mark_attendance(student_id, best_name, class_name, period, subject, period_start=period_start)
    logger.info("Attendance marked: %s (%s) period=%s", best_name, student_id, period)
    reset_session()
    subject_label = f" — {subject}" if subject else ""
    return _freeze(f"Attendance Marked: {best_name}{subject_label}")
