import cv2
import numpy as np
import os

BASE_DIR  = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MODEL_DIR = os.path.join(BASE_DIR, "models")

PROTO = os.path.join(MODEL_DIR, "deploy.prototxt")
MODEL = os.path.join(MODEL_DIR, "mobilenet_iter_73000.caffemodel")

net = cv2.dnn.readNetFromCaffe(PROTO, MODEL)

# PASCAL VOC classes used by this SSD MobileNet model
CLASSES = [
    "background", "aeroplane", "bicycle", "bird", "boat",
    "bottle", "bus", "car", "cat", "chair",
    "cow", "diningtable", "dog", "horse",
    "motorbike", "person", "pottedplant",
    "sheep", "sofa", "train", "tvmonitor"
]

SUSPICIOUS_CLASSES = {"tvmonitor"}


def detect_device(frame) -> tuple[bool, list]:
    """
    Detect phones / screens using SSD MobileNet + rectangle-screen heuristic.

    Returns:
        (detected: bool, boxes: list of [x1, y1, x2, y2])
    """
    # -- Pass 1: SSD MobileNet (catches TVs / monitors held up) --
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(
        cv2.resize(frame, (300, 300)), 0.007843, (300, 300), 127.5
    )
    net.setInput(blob)
    detections = net.forward()

    boxes = []
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence < 0.45:
            continue
        idx   = int(detections[0, 0, i, 1])
        label = CLASSES[idx] if idx < len(CLASSES) else "unknown"
        if label in SUSPICIOUS_CLASSES:
            box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
            boxes.append(box.astype(int).tolist())

    if boxes:
        return (True, boxes)

    # -- Pass 2: Rectangle-screen heuristic (catches phone screens) --
    if _detect_screen_rectangle(frame):
        return (True, [])

    return (False, [])


def _detect_screen_rectangle(frame) -> bool:
    """
    Detect a phone/tablet screen by looking for bright regions with:
      - 4 corners (full screen visible), OR
      - 3 corners (partial screen: 2 edges form an L, or 1 corner is clipped
                   by the frame edge — i.e. phone held at the side/top)
    plus right-angle corners and uniformly bright interior.

    Visible corner scenarios handled:
      Full screen  → approxPolyDP gives 4 vertices (all 4 corners in frame)
      3 corners    → approxPolyDP gives 4 vertices (one side partially cut)
      2 adj corners→ approxPolyDP gives 3 vertices (L-shape, two edges visible)
    """
    gray       = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    fh, fw     = gray.shape
    frame_area = fh * fw

    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges   = cv2.Canny(blurred, 50, 150)

    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        area = cv2.contourArea(cnt)
        # 5% threshold catches partial screens (vs 8% for a full screen)
        if area < 0.05 * frame_area:
            continue

        peri   = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        n      = len(approx)

        # Accept 3 corners (L-shape / partial) or 4 corners (full rectangle)
        if n not in (3, 4):
            continue

        # Screen edges are perpendicular — require right-angle corners.
        # 4-corner shape: at least 2 right angles (rectangle).
        # 3-corner shape: at least 1 right angle (L-shape corner).
        min_right = 2 if n == 4 else 1
        if not _has_right_angle_corners(approx, min_count=min_right):
            continue

        # Interior must be bright AND uniform (screen-like, not a face/wall)
        mask = np.zeros(gray.shape, dtype=np.uint8)
        cv2.drawContours(mask, [cnt], -1, 255, cv2.FILLED)
        mean_val, std_val = cv2.meanStdDev(gray, mask=mask)

        if mean_val[0][0] > 150 and std_val[0][0] < 60:
            return True

    return False


def _has_right_angle_corners(approx, min_count: int = 1) -> bool:
    """
    Return True if the polygon has at least `min_count` corners
    whose interior angle is within ±20° of 90°.
    """
    pts = approx.reshape(-1, 2).astype(float)
    n   = len(pts)
    count = 0

    for i in range(n):
        p1 = pts[(i - 1) % n]
        p2 = pts[i]           # the corner being tested
        p3 = pts[(i + 1) % n]

        v1    = p1 - p2
        v2    = p3 - p2
        norm1 = np.linalg.norm(v1)
        norm2 = np.linalg.norm(v2)

        if norm1 < 1e-6 or norm2 < 1e-6:
            continue

        cos_a = np.clip(np.dot(v1, v2) / (norm1 * norm2), -1.0, 1.0)
        angle = np.degrees(np.arccos(cos_a))

        if 70.0 <= angle <= 110.0:   # right angle ±20°
            count += 1

    return count >= min_count
