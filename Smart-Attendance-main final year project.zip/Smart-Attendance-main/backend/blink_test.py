from flask import Flask, render_template, request, jsonify
import cv2
import base64
import numpy as np
import mediapipe as mp
# ---- Blink state ----
eye_closed = False
blink_count = 0


app = Flask(__name__, template_folder="../templates")

# -------- MediaPipe Face Mesh --------
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]

def decode_image(image_b64):
    if not image_b64 or "," not in image_b64:
        return None

    try:
        header, encoded = image_b64.split(",", 1)
        data = base64.b64decode(encoded)
        if len(data) == 0:
            return None

        img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        return img
    except Exception:
        return None


def eye_ratio(eye, lm, w, h):
    top = lm[eye[1]]
    bottom = lm[eye[5]]
    left = lm[eye[0]]
    right = lm[eye[3]]

    vertical = abs(top.y - bottom.y) * h
    horizontal = abs(left.x - right.x) * w

    return vertical / horizontal

@app.route("/")
def home():
    return render_template("blink.html")

@app.route("/api/blink", methods=["POST"])
def blink_api():
    global eye_closed, blink_count

    frame = decode_image(request.json.get("image"))

    if frame is None:
        return jsonify({"status": "Waiting for camera..."})

    h, w, _ = frame.shape

    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)

    if not results.multi_face_landmarks:
        return jsonify({"status": "No face detected"})

    lm = results.multi_face_landmarks[0].landmark

    left = eye_ratio(LEFT_EYE, lm, w, h)
    right = eye_ratio(RIGHT_EYE, lm, w, h)
    ear = (left + right) / 2

    # ---- PROPER BLINK LOGIC ----
    if ear < 0.18:
        if not eye_closed:
            eye_closed = True
    else:
        if eye_closed:
            blink_count += 1
            eye_closed = False

    if blink_count >= 1:
        return jsonify({"status": "BLINK DETECTED ✅"})
    else:
        return jsonify({"status": "Eyes Open"})


if __name__ == "__main__":
    app.run(debug=True)
