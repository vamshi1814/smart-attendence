import os
import sys
import logging
from functools import wraps
from flask import (Flask, render_template, request, jsonify,
                   session, redirect, url_for)
from flask_cors import CORS

# ---------- PATH FIX ----------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, BASE_DIR)

from vision import register_face, take_attendance, reset_session
from database import (
    init_db, get_all_students, get_student_by_sid, add_student, delete_student,
    verify_student_login, reset_password, get_classes,
    add_timetable_entry, get_timetable, delete_timetable_entry, get_current_period,
    get_all_attendance, get_attendance_by_student, get_attendance_today, get_today_stats
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ---------- FLASK SETUP ----------
app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static")
)
app.secret_key = os.environ.get("SECRET_KEY", "smart_attend_secret_2024")
CORS(app)

ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "admin123")

init_db()


# ============================================================
# AUTH DECORATORS
# ============================================================
def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return wrapper


def student_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if session.get("role") != "student":
            return redirect(url_for("student_login"))
        return f(*args, **kwargs)
    return wrapper


# ============================================================
# ROOT
# ============================================================
@app.route("/")
def root():
    if session.get("role") == "admin":
        return redirect(url_for("admin_dashboard"))
    if session.get("role") == "student":
        return redirect(url_for("user_dashboard"))
    return render_template("index.html")


# ============================================================
# STUDENT AUTH
# ============================================================
@app.route("/login", methods=["GET", "POST"])
def student_login():
    if request.method == "POST":
        sid      = request.form.get("student_id", "").strip()
        password = request.form.get("password", "")
        student  = verify_student_login(sid, password)
        if student:
            session["role"]          = "student"
            session["student_id"]    = student["student_id"]
            session["student_name"]  = student["name"]
            session["student_class"] = student["class_name"]
            reset_session()
            return redirect(url_for("user_dashboard"))
        return render_template("login.html", error="Invalid Student ID or Password")
    return render_template("login.html")


# ============================================================
# ADMIN AUTH
# ============================================================
@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["role"] = "admin"
            return redirect(url_for("admin_dashboard"))
        return render_template("admin_login.html", error="Invalid credentials")
    return render_template("admin_login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("root"))


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        sid      = request.form.get("student_id", "").strip()
        new_pw   = request.form.get("new_password", "")
        confirm  = request.form.get("confirm_password", "")

        if not sid or not new_pw or not confirm:
            return render_template("forgot_password.html", error="All fields are required.")
        if new_pw != confirm:
            return render_template("forgot_password.html", error="Passwords do not match.")
        if len(new_pw) < 4:
            return render_template("forgot_password.html", error="Password must be at least 4 characters.")

        # Verify student exists before allowing reset
        student = get_student_by_sid(sid)
        if not student:
            return render_template("forgot_password.html",
                                   error="No student found with that ID. Contact your admin.")

        reset_password(sid, new_pw)
        logger.info("Password reset for student: %s", sid)
        return render_template("forgot_password.html",
                               success="Password reset successfully. You can now log in.")

    return render_template("forgot_password.html")


# ============================================================
# ADMIN PAGES
# ============================================================
@app.route("/admin/dashboard")
@admin_required
def admin_dashboard():
    stats = get_today_stats()
    today_records = get_attendance_today()
    return render_template("admin_dashboard.html", stats=stats,
                           today_records=today_records)


@app.route("/admin/students")
@admin_required
def admin_students():
    students       = get_all_students()
    today_records  = get_attendance_today()
    marked_ids     = {r["student_id"] for r in today_records}
    return render_template("admin_students.html",
                           students=students, marked_ids=marked_ids)


@app.route("/admin/register")
@admin_required
def admin_register():
    classes = get_classes()
    return render_template("admin_register.html", classes=classes)


@app.route("/admin/timetable")
@admin_required
def admin_timetable():
    entries = get_timetable()
    classes = get_classes()
    return render_template("admin_timetable.html", entries=entries, classes=classes)


# ============================================================
# ADMIN APIs
# ============================================================
@app.route("/api/register", methods=["POST"])
@admin_required
def api_register():
    data       = request.json or {}
    name       = data.get("name", "").strip()
    student_id = data.get("student_id", "").strip()
    class_name = data.get("class_name", "").strip()
    password   = data.get("password", "").strip()
    image      = data.get("image", "")

    if not all([name, student_id, class_name, password, image]):
        return jsonify({"message": "All fields are required"}), 400

    try:
        face_result = register_face(name, image)
        if "error" in face_result.get("message", "").lower():
            return jsonify(face_result), 400
    except Exception as e:
        logger.error("register_face error: %s", e)
        return jsonify({"message": "Face registration failed"}), 500

    if not add_student(name, student_id, class_name, password):
        return jsonify({"message": f"Student ID '{student_id}' already exists"}), 409

    logger.info("Registered student: %s (%s)", name, student_id)
    return jsonify({"message": f"Student '{name}' registered successfully"})


@app.route("/api/students/<student_id>", methods=["DELETE"])
@admin_required
def api_delete_student(student_id):
    delete_student(student_id)
    return jsonify({"message": "Student deleted"})


@app.route("/api/timetable", methods=["POST"])
@admin_required
def api_add_timetable():
    data = request.json or {}
    required = ["class_name", "subject", "day", "period", "start_time", "end_time"]
    if not all(data.get(k, "").strip() if isinstance(data.get(k), str) else data.get(k) for k in required):
        return jsonify({"message": "All timetable fields required"}), 400
    try:
        add_timetable_entry(
            data["class_name"], data["subject"], data["day"],
            int(data["period"]), data["start_time"], data["end_time"]
        )
        return jsonify({"message": "Timetable entry added"})
    except Exception as e:
        logger.error("add_timetable error: %s", e)
        return jsonify({"message": "Failed to add entry"}), 500


@app.route("/api/timetable/<int:entry_id>", methods=["DELETE"])
@admin_required
def api_delete_timetable(entry_id):
    delete_timetable_entry(entry_id)
    return jsonify({"message": "Entry deleted"})


@app.route("/admin/dashboard/data")
@admin_required
def admin_dashboard_data():
    """Polling endpoint — admin dashboard refreshes this every 10 s."""
    return jsonify({
        "stats":         get_today_stats(),
        "today_records": get_attendance_today()
    })


# ============================================================
# USER PAGES
# ============================================================
@app.route("/user/dashboard")
@student_required
def user_dashboard():
    student_id = session["student_id"]
    class_name = session["student_class"]
    history    = get_attendance_by_student(student_id)[:50]
    period     = get_current_period(class_name)
    return render_template("user_dashboard.html",
                           student_name=session["student_name"],
                           student_id=student_id,
                           class_name=class_name,
                           history=history,
                           current_period=period)


@app.route("/user/attendance")
@student_required
def user_attendance():
    class_name = session["student_class"]
    period     = get_current_period(class_name)
    return render_template("attendance.html",
                           student_name=session["student_name"],
                           current_period=period)


# ============================================================
# ATTENDANCE API  (student must be logged in)
# ============================================================
@app.route("/api/attendance", methods=["POST"])
@student_required
def api_attendance():
    data  = request.json or {}
    image = data.get("image", "")
    if not image:
        return jsonify({"message": "Image required"}), 400

    student_id   = session["student_id"]
    student_name = session["student_name"]
    class_name   = session["student_class"]

    # Check active period
    period_info = get_current_period(class_name)
    if not period_info:
        return jsonify({"message": "No active class right now"})

    try:
        result = take_attendance(
            image_b64    = image,
            student_id   = student_id,
            student_name = student_name,
            class_name   = class_name,
            period_info  = period_info
        )
        return jsonify(result)
    except Exception as e:
        logger.error("Attendance error: %s", e)
        return jsonify({"message": "Attendance processing failed"}), 500


@app.route("/api/reset", methods=["POST"])
@student_required
def api_reset():
    """Reset liveness state when student opens the attendance page."""
    reset_session()
    return jsonify({"status": "ok"})


# ============================================================
# LEGACY / HEALTH
# ============================================================
@app.route("/dashboard")
def legacy_dashboard():
    if session.get("role") == "admin":
        records = get_all_attendance()
        return render_template("dashboard.html", records=records)
    return redirect(url_for("root"))


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False)
