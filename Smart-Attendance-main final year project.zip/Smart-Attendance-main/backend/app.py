import os
import sys
import time
import logging
import cv2
import numpy as np
import mediapipe as mp
from deepface import DeepFace
from numpy.linalg import norm

# ---------- PATH FIX ----------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, BASE_DIR)

from agent.decision_agent import AttendanceAgent
from backend.database import mark_attendance, is_already_marked, init_db
from backend.object_guard import detect_device

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ---------- CONFIG ----------
KNOWN_FACES_PATH      = os.path.join(BASE_DIR, "data", "known_faces")
THRESHOLD             = 0.72
DEEPFACE_INTERVAL     = 12   # run recognition every N frames
DEVICE_CHECK_INTERVAL = 15   # run phone detection every N frames
ACK_DISPLAY_TIME      = 4.0  # seconds to show "Attendance Marked" message
WARNING_DISPLAY_TIME  = 3.5  # seconds to show phone warning

# ---------- INIT ----------
init_db()
agent = AttendanceAgent(threshold=THRESHOLD)

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

mp_face_mesh = mp.solutions.face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

LEFT_EYE  = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]
NOSE_TIP  = 1

# ---------- UTILS ----------
def cosine_distance(a, b):
    return 1.0 - np.dot(a, b) / (norm(a) * norm(b))

def eye_ratio(eye, lm, w, h):
    return abs(lm[eye[1]].y - lm[eye[5]].y) * h / (
           abs(lm[eye[0]].x - lm[eye[3]].x) * w)

# ---------- WEBCAM ----------
cap = cv2.VideoCapture(0)

# ---- LIVENESS STATE ----
blink_count    = 0
eye_closed     = False
head_left      = False
head_right     = False
initial_nose_x = None
blink_ok       = False
head_ok        = False

# ---- UI STATE ----
frame_count          = 0
label                = "Detecting..."
color                = (0, 255, 255)
last_device_detected = False
last_ack_time        = None
ack_message          = ""
ack_color            = (0, 255, 0)
last_warning_time    = None
warning_message      = ""

logger.info("Smart Attendance System started | Press 'q' to quit")

# ================= MAIN LOOP =================
while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    frame_count += 1
    current_time = time.time()

    # ---------- DEVICE DETECTION (THROTTLED) ----------
    if frame_count % DEVICE_CHECK_INTERVAL == 0:
        device_found, _ = detect_device(frame)
        last_device_detected = device_found
    else:
        device_found = last_device_detected

    if device_found:
        last_warning_time = current_time
        warning_message   = "PHONE / SCREEN DETECTED - ATTENDANCE BLOCKED"

    gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(
        gray, scaleFactor=1.2, minNeighbors=5, minSize=(80, 80)
    )

    if len(faces) > 0:
        x, y, w, h = faces[0]
        face_img = frame[y:y+h, x:x+w]
        cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 255, 0), 2)

        # ---------- LIVENESS CHECK ----------
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        res = mp_face_mesh.process(rgb)

        if res.multi_face_landmarks:
            lm = res.multi_face_landmarks[0].landmark

            # ---- BLINK ----
            ear = (
                eye_ratio(LEFT_EYE,  lm, frame.shape[1], frame.shape[0]) +
                eye_ratio(RIGHT_EYE, lm, frame.shape[1], frame.shape[0])
            ) / 2

            if ear < 0.18:
                eye_closed = True
            elif eye_closed:
                blink_count += 1
                eye_closed   = False

            if blink_count >= 1:
                blink_ok = True

            # ---- HEAD MOVEMENT ----
            nose_x = lm[NOSE_TIP].x * frame.shape[1]
            if initial_nose_x is None:
                initial_nose_x = nose_x

            diff = nose_x - initial_nose_x
            if diff < -25:
                head_left = True
            elif diff > 25:
                head_right = True

            if head_left and head_right:
                head_ok = True

        # ---------- USER GUIDANCE ----------
        if not last_ack_time:
            if not blink_ok:
                label = "Blink your eyes"
                color = (0, 255, 255)
            elif not head_ok:
                label = "Turn head LEFT and RIGHT"
                color = (0, 255, 255)

        # ---------- FACE RECOGNITION (THROTTLED) ----------
        if (
            frame_count % DEEPFACE_INTERVAL == 0
            and blink_ok and head_ok
            and not device_found
        ):
            if not os.path.exists(KNOWN_FACES_PATH):
                label = "No registered faces"
                color = (0, 0, 255)
            else:
                try:
                    face_rgb = cv2.resize(face_img, (224, 224))
                    face_rgb = cv2.cvtColor(face_rgb, cv2.COLOR_BGR2RGB)

                    live_emb = DeepFace.represent(
                        img_path=face_rgb,
                        model_name="VGG-Face",
                        detector_backend="skip",
                        enforce_detection=False
                    )[0]["embedding"]

                    name  = "Unknown"
                    min_d = 1.0

                    for f in os.listdir(KNOWN_FACES_PATH):
                        if not f.endswith(".npy"):
                            continue
                        emb = np.load(os.path.join(KNOWN_FACES_PATH, f))
                        d   = cosine_distance(live_emb, emb)
                        if d < min_d:
                            min_d = d
                            name  = f.replace(".npy", "")

                    if min_d < THRESHOLD:
                        if is_already_marked(name):
                            label = f"Already Marked: {name}"
                            color = (0, 165, 255)
                        else:
                            decision, _ = agent.decide(True, min_d, blink_ok, head_ok)
                            if decision == "MARK":
                                mark_attendance(name, "MARK", "Verified")
                                logger.info("Attendance marked: %s", name)
                                ack_message   = f"Attendance Marked: {name}"
                                ack_color     = (0, 255, 0)
                                last_ack_time = current_time

                                # Reset liveness for the next person
                                blink_count    = 0
                                eye_closed     = False
                                head_left      = False
                                head_right     = False
                                blink_ok       = False
                                head_ok        = False
                                initial_nose_x = None
                    else:
                        label = "Unknown Face"
                        color = (0, 0, 255)

                except Exception as e:
                    logger.error("Recognition error: %s", e)
                    label = "Recognition Failed"
                    color = (0, 0, 255)

    # ---------- PRIORITY DISPLAY ----------
    if last_warning_time and (current_time - last_warning_time) < WARNING_DISPLAY_TIME:
        cv2.putText(frame, warning_message,  (30, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
    elif last_ack_time and (current_time - last_ack_time) < ACK_DISPLAY_TIME:
        cv2.putText(frame, ack_message, (30, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, ack_color, 2)
    else:
        last_ack_time = None   # clear so guidance resumes
        cv2.putText(frame, label, (30, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow("Smart Attendance System", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
