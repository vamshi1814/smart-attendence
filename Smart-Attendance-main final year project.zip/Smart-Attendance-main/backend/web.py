import os
import sys
from flask import Flask, render_template

# ---------- PATH FIX ----------
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, BASE_DIR)

from backend.database import get_all_attendance, init_db

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "frontend")
)

init_db()

@app.route("/")
def dashboard():
    records = get_all_attendance()
    return render_template("index.html", records=records)

if __name__ == "__main__":
    app.run(debug=True)
