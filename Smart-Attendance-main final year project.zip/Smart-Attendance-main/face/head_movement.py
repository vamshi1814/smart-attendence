import cv2
import mediapipe as mp

# MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# Nose tip landmark
NOSE_TIP = 1

cap = cv2.VideoCapture(0)

initial_nose_x = None

print("🙂 Turn your head LEFT or RIGHT. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # ✅ Fix mirror image
    frame = cv2.flip(frame, 1)

    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)

    if results.multi_face_landmarks:
        landmarks = results.multi_face_landmarks[0].landmark
        nose_x = landmarks[NOSE_TIP].x * w

        if initial_nose_x is None:
            initial_nose_x = nose_x

        diff = nose_x - initial_nose_x

        direction = "CENTER"
        if diff > 25:
            direction = "RIGHT"
        elif diff < -25:
            direction = "LEFT"

        cv2.putText(frame, f"Direction: {direction}",
                    (30, 50), cv2.FONT_HERSHEY_SIMPLEX,
                    1, (0, 255, 0), 2)

        if direction in ["LEFT", "RIGHT"]:
            cv2.putText(frame, "Liveness Confirmed ✔",
                        (30, 90), cv2.FONT_HERSHEY_SIMPLEX,
                        1, (0, 200, 0), 2)

    cv2.imshow("Step 5 - Head Movement Liveness", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
