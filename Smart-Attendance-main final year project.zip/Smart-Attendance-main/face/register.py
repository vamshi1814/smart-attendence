import cv2
import numpy as np
import os
from deepface import DeepFace

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SAVE_PATH = os.path.join(BASE_DIR, "data", "known_faces")
os.makedirs(SAVE_PATH, exist_ok=True)

face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

name = input("Enter person name: ").strip()
cap = cv2.VideoCapture(0)

print("Press 's' to save | 'q' to quit")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.2, 5, minSize=(80, 80))
    face_img = None

    if len(faces) > 0:
        x, y, w, h = faces[0]
        face_img = frame[y:y+h, x:x+w]
        cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 2)

    cv2.imshow("Register Face", frame)
    key = cv2.waitKey(1) & 0xFF

    if key == ord('s') and face_img is not None:
        face_rgb = cv2.cvtColor(face_img, cv2.COLOR_BGR2RGB)
        face_rgb = cv2.resize(face_rgb, (224,224))

        embedding = DeepFace.represent(
            img_path=face_rgb,
            model_name="VGG-Face",
            detector_backend="skip",
            enforce_detection=False
        )[0]["embedding"]

        np.save(os.path.join(SAVE_PATH, f"{name}.npy"), embedding)
        print("Face registered:", name)
        break

    if key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
