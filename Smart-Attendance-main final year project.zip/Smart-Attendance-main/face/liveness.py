import cv2
import mediapipe as mp

# Initialize MediaPipe Face Mesh
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    static_image_mode=False,
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# Eye landmark indices (MediaPipe)
LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]

# ✅ MediaPipe-safe eye ratio
def eye_ratio(eye, landmarks, w, h):
    top = landmarks[eye[1]]
    bottom = landmarks[eye[5]]
    left = landmarks[eye[0]]
    right = landmarks[eye[3]]

    vertical = abs(top.y - bottom.y) * h
    horizontal = abs(left.x - right.x) * w

    return vertical / horizontal

# Webcam
cap = cv2.VideoCapture(0)
blink_count = 0
eye_closed = False

print("👁️ Blink to prove liveness. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    h, w, _ = frame.shape
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)

    if results.multi_face_landmarks:
        landmarks = results.multi_face_landmarks[0].landmark

        left_ratio = eye_ratio(LEFT_EYE, landmarks, w, h)
        right_ratio = eye_ratio(RIGHT_EYE, landmarks, w, h)
        ear = (left_ratio + right_ratio) / 2

        print("Eye ratio:", round(ear, 3))

        # ✅ Correct blink logic for MediaPipe
        if ear < 0.18:
            if not eye_closed:
                blink_count += 1
                eye_closed = True
        else:
            eye_closed = False

        cv2.putText(frame, f"Blinks: {blink_count}",
                    (30, 50), cv2.FONT_HERSHEY_SIMPLEX,
                    1, (0, 255, 0), 2)

    cv2.imshow("Step 4 - Liveness (Blink Detection)", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
